<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductPrice extends Model
{
    protected $table="product_price";
    protected $primaryKey = 'product_price_id';
}
