<?php
namespace App\Http\Controllers;

use Illuminate\Support\Facades\File;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Response;

use App\Product;
use App\ProductPrice;

class ProductController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       
         
         //Task 1: Consume https://api.codingtest.com.au/product/products?brandid=153&pageNum=1&pageSize=5 API
         /* 
         * $client = new Client();
         * $response = $client->request('GET', 'https://api.codingtest.com.au/product/products',['brandid'=>153,'pageNum'=>1,'pageSize'=>5]);
         * $statusCode = $response->getStatusCode();
         * 
         * $products=array();
         * 
         * if($statusCode==200){
         *      $products = $response->getBody()->getContents();
         * }
         */
        
        //Task 2:Develop the code:
        
        //Dummy response from success.json file
        $products = json_decode(File::get(base_path('tests/success.json')));

        $productsWithPrice = array();
        
        if(empty($products) || $products==null){
            return  $productsWithPrice;
        }
                
        foreach ($products as $product) {
            
            //a.	For each productNr, read the �unit_price� and �quantity� from a database table called �product_price� and compute the total_price (unit_price * quantity)
           
            // Calculate total price for product
            $productPrice = ProductPrice::select('quantity', 'unit_price', 'currency')->where('productNr', $product->ProductNr)->first();
            $product->TotalPrice = round($productPrice->quantity * $productPrice->unit_price, 2);
            $product->Currency = $productPrice->currency;

            // b.	Persist the data in the JSON response along with total_price in a database table called �products�
            // Create/Update in product table
            Product::updateOrCreate([
                "product_nr" => $product->ProductNr
            ], [
                "standard_description" => $product->StandardDescription,
                "standard_description_id" => $product->StandardDescriptionID,
                "brand_id" => $product->BrandID,
                "brand_name" => $product->BrandName,
                "total_price" => $product->TotalPrice,
                "currency" => $product->Currency
            ]);

            $productsWithPrice[] = $product;
        }

        
        //JSON response along with total_price
        return $productsWithPrice;


       }

}
