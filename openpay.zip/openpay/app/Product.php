<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Product extends Model
{
    protected $table="products";
    protected $fillable=["product_nr","standard_description","standard_description_id","brand_id","brand_name","total_price","currency"];
    protected $primaryKey = 'product_nr';
    
}
