<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-sm-12">
			<div class="full-right">
				<h2>Product List</h2>
				
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\openpay\resources\views/products/list.blade.php ENDPATH**/ ?>